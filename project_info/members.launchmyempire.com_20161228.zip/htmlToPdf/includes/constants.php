<?php


    defined('DB_SERVER') ? null : define("DB_SERVER", "localhost");
    defined('DB_USER') ? null : define("DB_USER", "lMEDbUser987");
    defined('DB_PASS') ? null : define("DB_PASS", "159LME**!232");
    defined('DB_NAME') ? null : define("DB_NAME", "launchmyempire");
    defined('SITE_URL') ? null : define('SITE_URL', 'http://members.launchmyempire.com/htmltoPdf/');
 
defined('TEMPLATE_PATH') ? null : define("TEMPLATE_PATH", "templates/");
defined('PDF_PATH') ? null : define("PDF_PATH", "TempFilesDirectory/");
?>
