<?php

require_once('Database.php');



class DatabaseObject {



}

?>