<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="main-container">



	<?php include_once("top_nav.php"); ?>
	<?php

		if(isset($video_number_n)&&($video_number_n>=$module_videos)){
			$module_number_n += 1;
			$video_number_n = 0;
		}

		if($video_number == 1){
			$module_number -= 1;
			$video_number = $countPrevModuleVideos+1;
		}


	?>

	<div class="padding-md">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<div class="panel-tab">
							<ul class="wizard-steps">
								<li class="<?php  $tabnumber = $this->uri->segment(5); if(empty($tabnumber)){echo "active videotab"; }else{echo "active videotab";} ?>">
									<a href="<?php echo base_url()."home/module/".$this->uri->segment(3); ?>"><?php echo "Module # ".$this->uri->segment(3); ?> </a>
								</li>

								<li class="<?php  $tabnumber = $this->uri->segment(5); if($tabnumber == 1){echo "active videotab"; }else{echo "active videotab";} ?>">
									<a href="<?php echo base_url()."home/video/".$this->uri->segment(3)."/".$selected_video[0]['video_number']."/1"; ?>"><?php echo "Video # ".$this->uri->segment(4); ?></a>
								</li>
								<li class="<?php  $tabnumber = $this->uri->segment(5); if($tabnumber == 2){echo "active videotab"; }else{echo "active videotab";} ?>">
									<a href="<?php echo base_url()."home/video/".$this->uri->segment(3)."/".$selected_video[0]['video_number']."/2"; ?>"><?php echo $selected_video[0]['video_title']; ?></a>
								</li>
							</ul>
						</div>
					</div>
					<?php if($TotalModulesToOpen>=$this->uri->segment(3)){ ?>
					<div class="panel-body">
						<?php echo $selected_video[0]['video_filename'] ?>
						<hr/>
						<div id="container">
							<div style="float: right;"><a href="<?php echo  base_url(); ?>home/video/<?php echo $module_number_n ?>/<?php echo $video_number_n+1; ?>" class="btn btn-primary">Next <i class="fa fa-chevron-right"></i></a></div>
							<div style="float: left;"><a href="<?php echo  base_url(); ?>home/video/<?php echo $module_number ?>/<?php echo $video_number-1; ?>" class="btn btn-primary" <?php if(($module_number==0)){ echo "disabled";}?>><i class="fa fa-chevron-left"></i> Prev</a></div>
						</div>
					</div>
					<?php }else{ ?>
						<div class="panel-body">
							<div class="alert alert-danger">
								<strong>Module is Locked!.!</strong> Currently this module is locked in your account.
							</div>
							<hr/>
							<div id="container">

								<div style="float: right;"><a href="<?php echo  base_url(); ?>home/video/<?php echo $module_number_n ?>/<?php echo $video_number_n+1; ?>" class="btn btn-primary" <?php if($module_number_n>$module_count){ echo "disabled";}?>>Next <i class="fa fa-chevron-right"></i></a></div>
								<div style="float: left;"><a href="<?php echo  base_url(); ?>home/video/<?php echo $module_number; ?>/<?php echo $video_number-1; ?>" class="btn btn-primary"><i class="fa fa-chevron-left"></i> Prev</a></div>
							</div>
						</div>
					<?php } ?>
				</div><!-- /panel -->
			</div>
		</div>
	</div>
</div>

