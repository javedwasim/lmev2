<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div id="main-container">
	

	<?php include_once("top_nav.php"); ?>
	<div class="padding-md">
		<div class="row" id="heading">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<a href = "<?php echo base_url()."home/module/".$module_number; ?>" class="module-color-custom font-16"><?php echo $module_title; ?></a>
					</div>
				</div><!-- /panel -->
			</div>
		</div>
		
		<div class="row">
			<div class="cols-md-12">
				<div class="panel">
					<div class="panel-body">
						<?php foreach($module_vides as $video): if($video['module_number']>$TotalModulesToOpen): ?>
							<div class="alert alert-danger">
								<strong>You have not access to this module.!</strong> Change a few things up and try submitting again.
							</div>
						<?php   break;  endif; ?>
							<div class="col-md-6">
								<div class="panel panel-default">
									<div class="panel-heading font18bold videocustom">

										<a href="<?php echo base_url()."/home/video/".$video['module_number']."/".$video['video_number']; ?>" class = "videotitlecolor">
											<?php echo "Video # ".$video['video_number']; ?>
										</a>
									</div>
									<div class="panel-body">
										<a href="<?php echo base_url()."home/video/".$video['module_number']."/".$video['video_number']; ?>" class="">
										<img width="64" height="64" src="<?php echo base_url(); ?>img/video-camera-icon.png" />
										&nbsp;&nbsp;
										<strong style="font-size:18px;"><?php echo $video['video_title']; ?></strong>
									</div>
								</div><!-- /panel -->
							</div>

						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>