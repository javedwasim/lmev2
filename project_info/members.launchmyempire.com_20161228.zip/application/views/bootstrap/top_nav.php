<div class="grey-container shortcut-wrapper">
		<a href = "<?php echo base_url(); ?>" class="shortcut-link">
			<span class="shortcut-icon">
				<i class="fa fa-home"></i>
			</span>
			<span class="text">Home</span>
		</a>
		<a href="<?php echo base_url()."home/coursemodules"; ?>" class="shortcut-link">
		<span class="shortcut-icon">

			<i class="fa fa-video-camera"></i>

		</span>
			<span class="text">Course Modules</span>
		</a>
		<a href="<?php echo base_url()."home/calendar"; ?>" class="shortcut-link">
		<span class="shortcut-icon">
			<i class="fa fa-calendar"></i>
		</span>
			<span class="text">Events Calender</span>
		</a>
		<a href="<?php echo base_url()."home/support"; ?>" class="shortcut-link">
		<span class="shortcut-icon">
			<i class="fa fa-question-circle"></i>

		</span>
			<span class="text">Contact Support</span>
		</a>
		<a href = "<?php echo base_url()."home/profile" ?>" class="shortcut-link">
		<span class="shortcut-icon">
			<i class="fa fa-user"></i>
		</span>
			<span class="text">My Profile</span>
		</a>
		<a href = "<?php echo base_url()."home/logout" ?>" class="shortcut-link">
		<span class="shortcut-icon">
			<i class="fa fa-power-off"></i>
		</span>
			<span class="text">Logout</span>

		</a>
	</div><!-- /grey-container -->