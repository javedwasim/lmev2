<!DOCTYPE html>
<html>

<body >
<div></div>

<div class="wrapper"> 
	<div id="titlepage" style="text-align:center;  background:rgb(189, 63, 38);min-height: 1300px;">
		<img src="http://members.launchmyempire.com/img/MAIN.png"/>
	</div>
	<div id="normalpages">
		<h1>YOUR BUSINESS PLAN DETAILS</h1>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 1: Create a List of Possible Niches
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
		<ol>
			<li>Niechie1</li>
			<li>N2</li>
			<li>N3</li>
			<li>N4</li>
			<li>N5</li>
			</ol>
		</div>
		
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 2: Finalize the Niche to Build
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			THis is FINAL
		</div>
		
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 3: Find 5 of The Top Products In Your Market
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
		<ol>
			<li><a href="http://thisisProductone.com">http://thisisProductone.com</a></li>
			<li><a href="http://thisisProductone.com">http://thisisProductone.com</a></li>
			<li><a href="http://thisisProductone.com">http://thisisProductone.com</a></li>
			<li><a href="http://thisisProductone.com">http://thisisProductone.com</a></li>
			<li><a href="http://thisisProductone.com">http://thisisProductone.com</a></li>
			</ol>
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 4: Look For Common Trends In Your Market
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ol>
				<li><a href="http://helloworld.com">http://helloworld.com</a><br /><br />
					<ul>
						<li><strong>Price:</strong> [100], <strong>Type:</strong>[Graphics Software], <strong>Sold on:</strong> [JVZooo] ([Network])</li>
						<li><strong>Main hook:</strong> [This is the sample content for main hook]</li>
						<li><strong>Provides</strong>: [This is provide all data]</li>
					</ul>
				</li><br/>
		
				<li><a href="http://helloworld.com">http://helloworld.com</a><br /><br />
					<ul>
						<li><strong>Price:</strong> [100], <strong>Type:</strong>[Graphics Software], <strong>Sold on:</strong> [JVZooo] ([Network])</li>
						<li><strong>Main hook:</strong> [This is the sample content for main hook]</li>
						<li><strong>Provides</strong>: [This is provide all data]</li>
					</ul>
				</li><br/>

				<li><a href="http://helloworld.com">http://helloworld.com</a><br /><br />
					<ul>
						<li><strong>Price:</strong> [100], <strong>Type:</strong>[Graphics Software], <strong>Sold on:</strong> [JVZooo] ([Network])</li>
						<li><strong>Main hook:</strong> [This is the sample content for main hook]</li>
						<li><strong>Provides</strong>: [This is provide all data]</li>
					</ul>
				</li><br/>

				<li><a href="http://helloworld.com">http://helloworld.com</a><br /><br />
					<ul>
						<li><strong>Price:</strong> [100], <strong>Type:</strong>[Graphics Software], <strong>Sold on:</strong> [JVZooo] ([Network])</li>
						<li><strong>Main hook:</strong> [This is the sample content for main hook]</li>
						<li><strong>Provides</strong>: [This is provide all data]</li>
					</ul>
				</li><br/>

				<li><a href="http://helloworld.com">http://helloworld.com</a><br /><br />
					<ul>
						<li><strong>Price:</strong> [100], <strong>Type:</strong>[Graphics Software], <strong>Sold on:</strong> [JVZooo] ([Network])</li>
						<li><strong>Main hook:</strong> [This is the sample content for main hook]</li>
						<li><strong>Provides</strong>: [This is provide all data]</li>
					</ul>
				</li><br/>
						
			</ol>
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 5: Determine Your Price
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			$250-$500
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 6: Determine The Type of Product You Will Create
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			Video - ScreenCapture
		</div>
		
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 7: Why Should Someone Buy Your Product?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
				<li><strong>URL:</strong> http://mytestwebsite.com/page1</li>
				<li><strong>Name:</strong> dsada</li>
				<li><strong>USP:</strong> sadsad</li>
				<li><strong>Benefits:</strong> asdsada</li>
			</ul>
		</div>
		
		
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 8 - part1: Let's Get a Detailed Idea of What's Inside Your Product
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
				<li>First Module</li>
				<li>First Module</li>
				<li>First Module</li>
				<li>First Module</li>
			</ul>
		</div>
		
		
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 8 - Part2 - Let's Dive Into Each Module Now!
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
			<li>First Module
			<ul>
			<li>bullets1</li>
			<li>bullets2</li>
			</ul>
			</li>
			<li>First Module
			<ul>
			<li>bullets1</li>
			<li>bullets2</li>
			</ul>
			</li>
			<li>First Module
			<ul>
			<li>bullets1</li>
			<li>bullets2</li>
			</ul>
			</li>
			<li>First Module
			<ul>
			<li>bullets1</li>
			<li>bullets2</li>
			</ul>
			</li>
			</ul>
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 9: Are You Going To Want Some Additional Help?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
				<li>Will you use outsourcing? : <strong>YES</strong></li>
				<li>Will you use expert interviews? :<strong> NO</strong></li>
			</ul>
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 10: Your Bonus Titles & Information
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
			<li><strong>Bounus Title #1</strong><br /><br />
			<ul>
			<li>Price: $200</li>
			<li>Type:Written</li>
			</ul>
			</li><br />
			<li><strong>Bounus Title # 2</strong><br /><br />
			<ul>
			<li>Price: $259</li>
			<li>Type:Audio</li>
			</ul>
			</li><br />
			<li><strong>Bounus Title # 3</strong><br /><br />
			<ul>
			<li>Price: $259</li>
			<li>Type:Video</li>
			</ul>
			</li><br />
			</ul>
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 11: Your Upsells
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			XXXX
		</div>
		
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 12: Are You Going To Want Some Additional Help For Upsells?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			<ul>
				<li>Will you use outsourcing? : <strong>YES</strong></li>
				<li>Will you use expert interviews? :<strong> NO</strong></li>
			</ul>
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 13: Which Technology Do You Want To use?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			This is sample technology
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 14: How Will You Reach Your Prospects & Customers? Which autoresponder do you want to use?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			abcdd dfaldfadfad
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 15: How Will You Transact Sales & Collect Revenue? Which payment processor do you want to use?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			XXsadsadsadsadsadsaXX
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 16: How Will You Take Great Care of Your Customers? Which customer support system do you want to use?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			XXXsdsadsadsadsadsadsadsaX
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 17: You Have 3 Options : Pick Your Favorite! How are you going to sell your product?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			sddsfdsfs
		</div>
		<div class="step" style="font-weight:bold; font-size:20px; color:#BD3F26;padding: 15px;text-decoration: underline;">
			Step # 18: Are you going to outsource your copywriting?
		</div>
		<div class="answer" style="border-bottom: 1px solid #BD3F26; padding-bottom: 25px;    padding-left: 15px;">
			Yes, I want to find a writer
		</div>
	</div>
</div>
</body>