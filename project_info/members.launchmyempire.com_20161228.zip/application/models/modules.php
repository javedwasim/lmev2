<?php

class Modules extends My_Model{

    function getAllModules(){
        $data = array();
        $this->db->select('id,module_number,module_title,video_count,video_number,video_title,tags,audio,pdf,video_filename');
        $this->db->group_by("module_number");
        $this->db->order_by('module_number','asc');
        $Q = $this->db->get('modules');

        if ($Q->num_rows() > 0){
            foreach ($Q->result_array() as $row){
                $data[] = $row;
            }
        }
        $Q->free_result();
        return $data;
    }

    function getAllModulesVideos($module_numnber){
        $data = array();
        $this->db->select('id,module_number,module_title,video_count,video_number,video_title,tags,audio,pdf,video_filename');
        $this->db->where('module_number', $module_numnber);
        $this->db->order_by('module_number','asc');
        $Q = $this->db->get('modules');

        if ($Q->num_rows() > 0){
            foreach ($Q->result_array() as $row){
                $data[] = $row;
            }
        }
        $Q->free_result();
        return $data;
    }

    function getSelectedModule($module_numnber){

        $data = array();
        $this->db->select('id,module_number,module_title,video_count,video_number,video_title,tags,audio,pdf,video_filename');

        $this->db->where('module_number', $module_numnber);
        $this->db->limit(1);
        $Q = $this->db->get('modules');

        if ($Q->num_rows() > 0){
            foreach ($Q->result_array() as $row){
                $data[] = $row;
            }
        }
        $Q->free_result();
        return $data;
    }


    function getSelectedModuleVideo($module_number , $video_numnber){
        $data = array();
        $this->db->select('id,module_number,module_title,video_count,video_number,video_title,tags,audio,pdf,video_filename');
        $this->db->where('module_number', $module_number);
        $this->db->where('video_number', $video_numnber);
        $this->db->limit(1);
        $Q = $this->db->get('modules');

        if ($Q->num_rows() > 0){
            foreach ($Q->result_array() as $row){
                $data[] = $row;
            }
        }
        $Q->free_result();
        return $data;
    }


    function countModuleVideos($module_number){
        $this->db->where('module_number', $module_number);
        $num_rows = $this->db->count_all_results('modules');
        return $num_rows;
    }


    function countLastModuleVideos($module_number){
        $this->db->where('module_number', $module_number);
        $num_rows = $this->db->count_all_results('modules');
        return $num_rows;
    }



}

?>
