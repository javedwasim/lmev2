<?php

class My_Model extends CI_Model{
    const DB_TABLE  = "abstract";
    const DB_TABLE_PK  = "abstract";
    
    
    
    /**
     * create record
     */
    private function insert(){
        $this->db->insert($this::DB_TABLE,$this);
        $this->{$this::DB_TABLE_PK} = $this->db->insert_id();    
    }
    
    /**
     * update record.
     */
    private function update() {
        $this->db->update($this::DB_TABLE, $this, array($this::DB_TABLE_PK => $this->issue_id));
    }
    
    /**
     * Populate from array or standard class
     */
    public function populate($row){
        foreach ($row as $key => $value){
            $this->$key = $value;
        }
    }
    
    /**
     * Load form database.
     * @param type int $id
     */
    public function load($id){
        $query = $this->db->get_where($this::DB_TABLE, array(
            $this::DB_TABLE_PK => $id,
        ));
        $this->populate($query->row());
    }
    
    /**
     * Delete the current record.
     */
    public function delete(){
        $this->db->delete($this::DB_TABLE, array(
            $this::DB_TABLE_PK => $this->{$this::DB_TABLE_PK},
       ));
       unset($this->{$this::DB_TABLE_PK});     
    }
    
    /**
     * Save record
     */
    public function save(){
        if(isset($this->{$this::DB_TABLE_PK})){
            $this->update();
        }else{
            $this->insert();
        }
    }
    
    public function get($limit = 0, $offset = 0){
        if($limit){
            $query = $this->db->get($this::DB_TABLE, $limit, $offset);
        }else{
            $query = $this->db->get($this::DB_TABLE);
        }
        
        $ret_val = array();
        $class = get_class($this);
        
        foreach ($query->result() as $row){
            $model = new $class;
            $model->populate($row);
            $ret_val[$row->{$this::DB_TABLE_PK}] = $model;
        }
        return $ret_val;
    }
    
    /**
     * 
     * count issue table record
     */
    
    public function record_count() {
        return $this->db->count_all("issues");
    }
    
    
}


?>